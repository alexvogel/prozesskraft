
README

This is another quick start example. It includes license GUI and methods for
all license types.

All packages includes two Java source files. MyProductMainJFrame.java file is our
example very simple Java application. Read source and just copy the code
commented as "COPY THIS LINE" and "COPY THIS METHOD" to your main Java file. Then
copy the second file which includes all licensing methods and a simple licensing
jdialog. Open jdialog source, and change only variables commented as "REQUIRED".
THAT IS ALL.


"com.example.licensing.FloatingLicenseText" package is a floating license text
example, you will need an installed floating license server to run/test it.

"com.example.licensing.LicenseKeyWithActivation" package is a license key example
with enabled activation. You can directly use following keys, they will be valid 
and can be activated on Online.License4J. CQAIQ-PE7GJ-K5UCL-Z4QEF-CUVM5

"com.example.licensing.LicenseTextWithOrWithoutActivation" package is license text
example. 1424097913281.l4j is the example license text file.

"com.example.licensing.OnlineLicenseKey" package is an example for online license
key. Sample license keys are ZFIGX-9EIBB-7AILW-KNQM7-K9YRL
YQIU9-IHBXI-U5LAQ-GFNED-RU2BV

