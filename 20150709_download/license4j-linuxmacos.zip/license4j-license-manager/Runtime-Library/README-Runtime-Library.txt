
README Runtime Library

LICENSE4J-Runtime-Library.jar file is the runtime library compiled with Java 1.6
and LICENSE4J-Library-javadoc.jar file is the javadoc. If you are using Java
version 1.6 or above, use this jar file.

LICENSE4J-Runtime-Library-JDK15.zip file includes the runtime library and javadoc compiled 
with Java 1.5.
