
README

This runtime library jar file is compiled/built with Java 1.5.

The only difference with the runtime library compiled/built with Java 1.6 is
that HardwareID class getHardwareIDFromEthernetAddress() method always returns
null. Therefore hardware ID from ethernet address cannot be used with this
runtime library.
