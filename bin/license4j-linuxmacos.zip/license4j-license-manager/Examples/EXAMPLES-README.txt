EXAMPLES README

example1 folder includes source code for validation of each license type.

example2 folder includes a Netbeans project for complete application with support for
validation of each license type. Application also save license information and
use at startup like a real product. 

example3 folder includes a Netbeans project to demonstrate License4J Runtime Library
obfuscation with with any application. You can find ant task, proguard config file 
and proguard itself.

example4 folder includes a Netbeans project. It demonstrates license key with activation
feature usage. It also includes trial license usage.

example5 folder includes an example to validate and activate license key/text. You
can directly use that example in your application to easily add licensing support.

example6 is a very small example application, only includes a JFrame. It includes jar file from
example5 to demonstrate how to integrate licensing in your software easily. Source file has comments,
and it only call methods from example5. It also includes hard-coded trial license key usage.
